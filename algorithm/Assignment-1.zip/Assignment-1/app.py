#!/usr/local/bin/python3
# -*- coding: utf-8 -*-
from src._bubble_sort import *
from src._heap_sort import *
from src._insert_sort import *
from src._merge_sort import *
from src._quick_sort import *
from src._select_sort import *
from src._load_data import *
from src._out_data import *
from src._interface import *
from src._listdir import *
import timeit


if __name__ =="__main__":
    path = os.getcwd()
    file_name = list_dir(path)
    orignal, field=load_data(path, file_name)
    data = orignal
    res = None
    attribute = 0

    try : 
        row = int(input("Input row in Data(row is only integer)>> "))
        
    except ValueError : 
        print ("Error :  invaild value ...")
        exit(0)
                
    #try :
    #    temp = int(data[1][row])
    
    #except ValueError:
    #    print ("Error : ROW IS NOT INTERGER...")
    #    exit(0)

    while True : 
        idx = menu()
        if idx  == 1 :
            res = bubble_sort(data, row)
            attribute = 1

        elif idx == 2 :
            res = insert_sort(data, row)
            attribute = 2

        elif idx == 3 : 
            res = select_sort(data, row)
            attribute = 3

        elif idx == 4 :
            res = heap_sort(data, row)
            attribute = 4

        elif idx == 5 :
            rec_merge_sort(data, row)
            res= data
            attribute = 5

        elif idx == 6 :
            res = seq_merge_sort(data, row)
            attribute = 6

        elif idx == 7:
            rec_quick_sort(data, row)
            res = data
            attribute = 7

        elif idx == 8 :
            res = seq_quick_sort(data, row)
            attribute = 8

        elif idx == 9 :
            out_data(path, attribute, res, field, file_name)

        elif idx == 0 :
            print ("bye bye ~ ")
            exit(0)

    



    
    


    #print (data)
    #print (bubble_sort(data, 0))
    #merge_sort(data)
    #insert_sort(data)
    #select_sort(data)
    #res = quick_sort_seq(data)
    #res = seq_merge_sort(data)
    #print (data)
    #heap_sort(data)
    #print (res)